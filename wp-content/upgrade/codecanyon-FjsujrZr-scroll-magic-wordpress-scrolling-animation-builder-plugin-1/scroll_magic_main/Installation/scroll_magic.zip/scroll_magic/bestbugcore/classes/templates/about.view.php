<div class="wpbb_about_page">
    <!-- <div class="wpbb_about_title">
    <?php include_once 'about.title.php'; ?>
    </div> -->
    <div class="wpbb_about_plugin">
    <?php include_once 'about.plugin.php'; ?>
    </div>
</div>