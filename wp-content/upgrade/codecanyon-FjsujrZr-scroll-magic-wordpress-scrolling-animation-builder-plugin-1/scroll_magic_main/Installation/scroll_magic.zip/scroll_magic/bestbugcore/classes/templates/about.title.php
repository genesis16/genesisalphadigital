<div class="wpbb-container">
    <div class="wpbb-left-section">
        <h3>Hey, <span>admin</span></h3>
        <h1>Welcome!</h1>
        <h4>Thank you for choosing wpbb Core — the ultimate tool for building professional websites. Use the tips below to get started. You will be up and running in no time.</h4>
        <a href="https://codecanyon.net/user/bestbug"  target="_blank" class="hero-button">Get Started</a><a href="https://codecanyon.net/user/bestbug" target="_blank" class="how-to-use">Learn How To Use</a>
    </div>
</div>