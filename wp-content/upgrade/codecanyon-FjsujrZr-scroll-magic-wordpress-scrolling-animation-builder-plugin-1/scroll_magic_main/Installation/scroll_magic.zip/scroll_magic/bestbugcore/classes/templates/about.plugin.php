<div class="wpbb-container">
    <div class="wpbb-plugin-title">
        
    </div>
    <div class="wpbb-plugin-content">
        <ul class="wpbb-list-ul">
        </ul>
    </div>
</div>